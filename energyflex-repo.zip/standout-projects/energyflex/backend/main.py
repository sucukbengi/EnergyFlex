from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import numpy as np, pandas as pd
from celery.result import AsyncResult
from tasks import schedule_optimization_task, celery_app

app = FastAPI(title="EnergyFlex API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class MeterPoint(BaseModel):
    kw: float
    ts: float

class ForecastRequest(BaseModel):
    last_hours: List[MeterPoint]

@app.get("/health")
def health():
    return {"ok": True, "version": "0.1.0"}

@app.post("/forecast")
def forecast(req: ForecastRequest):
    # Simple seasonal naive: average of last 24 points
    df = pd.DataFrame([{'ts':m.ts,'kw':m.kw} for m in req.last_hours]).sort_values('ts')
    avg = df['kw'].tail(24).mean() if len(df)>=1 else 5.0
    horizon = 24
    pred = [{'t': int(i), 'kw': float(avg*(1+0.1*np.sin(i/3.0)))} for i in range(horizon)]
    return {"horizon": horizon, "pred": pred}

class OptimizeRequest(BaseModel):
    max_kw: float = 20.0
    tasks: List[dict] # each: {'name':str,'kwh': float, 'duration': int hours, 'window':[start,end]}

@app.post("/optimize")
def optimize(req: OptimizeRequest):
    job = schedule_optimization_task.delay(req.dict())
    return {"job_id": job.id}

@app.get("/jobs/{job_id}")
def job_status(job_id: str):
    res = AsyncResult(job_id, app=celery_app)
    payload = {"id": job_id, "status": res.status}
    if res.successful():
        payload["result"] = res.get()
    return payload
