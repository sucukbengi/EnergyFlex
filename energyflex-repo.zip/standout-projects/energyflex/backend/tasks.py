import os, json
from celery import Celery
from ortools.sat.python import cp_model

redis_host = os.getenv("REDIS_HOST","redis")
celery_app = Celery('energyflex', broker=f"redis://{redis_host}:6379/0", backend=f"redis://{redis_host}:6379/0")

@celery_app.task
def schedule_optimization_task(payload):
    # small CP-SAT demo
    req = payload
    tasks = req['tasks']
    max_kw = float(req.get('max_kw', 20.0))
    model = cp_model.CpModel()
    horizon = 24
    # variables
    start_vars, end_vars, interval_vars, power = {}, {}, {}, {}
    for t in tasks:
        dur = int(t['duration'])
        start = model.NewIntVar(t['window'][0], t['window'][1]-dur, f"s_{t['name']}")
        end = model.NewIntVar(t['window'][0]+dur, t['window'][1], f"e_{t['name']}")
        interval = model.NewIntervalVar(start, dur, end, f"i_{t['name']}")
        start_vars[t['name']] = start; end_vars[t['name']] = end; interval_vars[t['name']] = interval
        power[t['name']] = float(t['kwh']/dur)
    # capacity per hour
    loads = [model.NewIntVar(0, int(max_kw*100), f"load_{h}") for h in range(horizon)]
    for h in range(horizon):
        # sum tasks active at hour h
        actives = []
        for t in tasks:
            dur = int(t['duration'])
            # boolean if task t is active at hour h
            b = model.NewBoolVar(f"active_{t['name']}_{h}")
            s = start_vars[t['name']]
            # h in [s, s+dur-1] -> use linearization
            model.Add(s <= h).OnlyEnforceIf(b)
            model.Add(s > h).OnlyEnforceIf(b.Not())
            model.Add(h <= end_vars[t['name']]-1).OnlyEnforceIf(b)
            model.Add(h > end_vars[t['name']]-1).OnlyEnforceIf(b.Not())
            actives.append((b, int(power[t['name']]*100)))
        # sum
        model.Add(loads[h] == sum(w * b for (b,w) in actives))
        model.Add(loads[h] <= int(max_kw*100))
    # objective: smoothness (minimize peak)
    peak = model.NewIntVar(0, int(max_kw*100), "peak")
    for h in range(horizon):
        model.Add(loads[h] <= peak)
    model.Minimize(peak)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 5.0
    res = solver.Solve(model)
    sol = {"status": str(res), "starts": {k: solver.Value(v) for k,v in start_vars.items()}}
    return sol
