# EnergyFlex — Demand Response & Forecasting (Starter MVP)

An educational MVP that forecasts a simple building load curve and schedules flexible devices to respect a max power limit, using:
- **Frontend:** Next.js + TypeScript (+ Plotly charts)
- **Backend:** FastAPI (Python)
- **Async/Batch:** Celery + Redis
- **Optimization:** OR-Tools CP-SAT demo

> This repo is kept intentionally small so you can understand the end-to-end workflow, then extend it into a portfolio-grade project.

## Quickstart

Prereqs: Docker Desktop (or Docker Engine)

```bash
docker compose up --build
```

Open:
- UI: http://localhost:3001  
- API health: http://localhost:8001/health  
- Redis: localhost:6379

In the UI:
1. Click **Run Forecast** to generate a dummy 24‑hour curve.
2. Click **Optimize Example Tasks** to send a small schedule to the CP-SAT solver.
3. Watch the job status; the result is rendered when Celery finishes.

## Services

| Service   | Port | Notes                                  |
|-----------|------|----------------------------------------|
| frontend  | 3001 | Next.js app                            |
| backend   | 8001 | FastAPI API                            |
| worker    |  —   | Celery worker connected to Redis       |
| beat      |  —   | Celery beat (periodic scheduling)      |
| redis     | 6379 | Broker + result backend                 |

## API

See **[docs/api.md](docs/api.md)** for request/response examples.

## Architecture

- A Next.js client calls `POST /forecast` (stateless demo) and `POST /optimize`.  
- `POST /optimize` enqueues a Celery job → a CP-SAT model computes a peak-minimizing schedule.  
- The client polls `GET /jobs/{id}` until `status = SUCCESS`.

Diagrams, decisions, and next steps live in **[docs/architecture.md](docs/architecture.md)**.

## Deploy

- **Local dev:** `docker compose up --build`  
- **Container registry:** `docker build` per service; push images  
- **Kubernetes:** Add simple manifests or Helm (see `docs/deploy.md` for a baseline)

## Tests

*(Optional)* Add tests in `backend/tests/` and wire to CI. A basic GitHub Actions workflow is included.

## License

MIT
