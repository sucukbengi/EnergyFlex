# Architecture & Roadmap

## High-level

- **Frontend (Next.js)**: Simple UI for forecasts and optimization; real product would add auth, multitenancy, maps, and device control adapters.
- **Backend (FastAPI)**: Thin API gateway for forecasting and scheduling requests.
- **Async (Celery + Redis)**: Long-running optimization tasks offloaded to a worker.
- **Optimization (OR-Tools)**: CP-SAT model minimizes peak load subject to device windows and power limits.

## Data model (future)
- `sites`, `devices`, `meters`, `tariffs`, `schedules`, `executions`
- Time-series storage with TimescaleDB; parquet export to S3 for analytics.

## Observability
- Add OpenTelemetry traces for API → Celery → solver.
- Use Prometheus + Grafana or CloudWatch metrics.

## Security
- JWT/OIDC auth (e.g., Auth0), RBAC by org/site.
- Signed webhooks for device adapters.

## Roadmap
1. Persist meter data in Postgres/TimescaleDB.
2. Replace naive forecast with XGBoost/Prophet and include weather features.
3. Add a what‑if simulator and tariff importer.
4. Implement device adapters (BACnet/Modbus/Home Assistant).
5. Add multi-tenant auth, audit logs, and per-site secrets.
6. Deploy to AWS ECS/EKS with IaC (Terraform).

