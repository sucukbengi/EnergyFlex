# Deploy Notes

## Docker images

Build locally:

```bash
docker compose build
```

Push individual images (example):

```bash
docker build -t <registry>/energyflex-backend:0.1 ./backend
docker push <registry>/energyflex-backend:0.1
```

## Kubernetes (sketch)

- Create `Deployment` + `Service` for `backend`, `frontend`, `worker`, `beat`.
- Use `Redis` Helm chart.
- Configure environment variables via `ConfigMap`/`Secret`.
- Add `Ingress` (e.g., NGINX) and TLS.

## GitHub Pages

For the docs site, you can publish `docs/` with MkDocs or just render README on your GitHub repo.
