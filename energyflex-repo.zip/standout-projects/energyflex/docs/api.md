# EnergyFlex API

Base URL (local): `http://localhost:8001`

## Health

`GET /health` → `{"ok": true, "version": "0.1.0"}`

## Forecast

`POST /forecast`

```json
{
  "last_hours": [
    {"kw": 10.2, "ts": 1720000000},
    {"kw": 9.8, "ts": 1720003600}
  ]
}
```

**Response**

```json
{
  "horizon": 24,
  "pred": [{"t": 0, "kw": 10.5}, {"t": 1, "kw": 10.7}, "..."]
}
```

## Optimize

`POST /optimize`

```json
{
  "max_kw": 8,
  "tasks": [
    { "name": "EV_Charge", "kwh": 12, "duration": 4, "window": [0,24] },
    { "name": "Dishwasher", "kwh": 2, "duration": 2, "window": [18,24] }
  ]
}
```

**Response**

```json
{ "job_id": "d1c0d6f8-..." }
```

## Job status

`GET /jobs/{job_id}`

**Response (success)**

```json
{
  "id": "d1c0d6f8-...",
  "status": "SUCCESS",
  "result": {
    "status": "4",
    "starts": { "EV_Charge": 0, "Dishwasher": 19 }
  }
}
```
