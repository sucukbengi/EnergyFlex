import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
const Plot = dynamic(()=>import('react-plotly.js'), {ssr:false});
const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8001';

type Pred = {t:number, kw:number};

export default function Home(){
  const [pred, setPred] = useState<Pred[]>([]);
  const [jobId, setJobId] = useState<string>('');
  const [result, setResult] = useState<any>(null);

  async function doForecast(){
    const now = Math.floor(Date.now()/1000);
    const last = Array.from({length:24}, (_,i)=>({kw: 10 + Math.sin(i/3)*2, ts: now - (24-i)*3600}));
    const r = await fetch(`${API}/forecast`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({last_hours: last})});
    const j = await r.json();
    setPred(j.pred);
  }

  async function doOptimize(){
    const tasks = [
      { name: "EV_Charge", kwh: 12, duration: 4, window: [0, 24] },
      { name: "Dishwasher", kwh: 2, duration: 2, window: [18, 24] },
      { name: "Laundry", kwh: 3, duration: 2, window: [8, 22] }
    ];
    const r = await fetch(`${API}/optimize`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({max_kw: 8, tasks})});
    const j = await r.json();
    setJobId(j.job_id);
    setResult(null);
  }

  useEffect(() => {
    if(!jobId) return;
    const t = setInterval(async () => {
      const r = await fetch(`${API}/jobs/${jobId}`);
      const j = await r.json();
      if(j.status === 'SUCCESS'){
        setResult(j.result);
        clearInterval(t);
      }
    }, 1000);
    return () => clearInterval(t);
  }, [jobId]);

  return (
    <main style={{padding:24,fontFamily:'sans-serif', maxWidth: 900, margin: '0 auto'}}>
      <h1>EnergyFlex — Forecast & Optimizer (demo)</h1>
      <section style={{marginTop: 16}}>
        <h2>1) Forecast</h2>
        <button onClick={doForecast} style={{padding:8}}>Run Forecast</button>
        <div style={{height: '50vh', marginTop: 12}}>
          <Plot data={[{ x: pred.map(p=>p.t), y: pred.map(p=>p.kw), mode: 'lines+markers'}]}
            layout={{title:'Next 24h Load (kW)', xaxis:{title:'hour'}, yaxis:{title:'kW'}}} style={{width:'100%', height:'100%'}}/>
        </div>
      </section>
      <section style={{marginTop: 16}}>
        <h2>2) Schedule Optimization</h2>
        <button onClick={doOptimize} style={{padding:8}}>Optimize Example Tasks</button>
        {jobId && !result && <p>Job {jobId} running…</p>}
        {result && (
          <div style={{marginTop: 8}}>
            <pre style={{background:'#f6f8fa', padding: 12, borderRadius: 6}}>
{JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </section>
    </main>
  );
}
